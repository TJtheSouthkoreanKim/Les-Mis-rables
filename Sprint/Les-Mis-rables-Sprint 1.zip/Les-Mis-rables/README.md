# Les-Mis-rables
 2022.23 Data Engineering Teams
# Note
This is the file which is containing the coursework specification for future references to help with the coursework
# Objects
[Assessment Criteria.pdf](https://github.com/TJtheSouthkoreanKim/Les-Mis-rables/files/10716255/Assessment.Criteria.pdf)

GithubLink-- https://github.com/TJtheSouthkoreanKim/Les-Mis-rables.git
